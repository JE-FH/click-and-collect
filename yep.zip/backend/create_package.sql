INSERT INTO package (guid, storeId, bookedTimeId, verificationCode, customerEmail, customerName, externalOrderId, creationDate) VALUES
    (1234, 4563, NULL, "akeoifkapekopaef", "larz@mail.com", "Larz Ingolf Brie", "#8000FF", "1617266834");

INSERT INTO package (guid, storeId, bookedTimeId, verificationCode, customerEmail, customerName, externalOrderId, creationDate) VALUES
    (1235, 4563, NULL, "akeoifkapekopaeg", "larz@mail.com", "Larz Ingolf Brie", "#8000AA", "1616866834");

INSERT INTO package (guid, storeId, bookedTimeId, verificationCode, customerEmail, customerName, externalOrderId, creationDate) VALUES
    (1236, 2, NULL, "akeoifkapekopaeh", "mamba@mail.com", "Black Mamba", "#8000AB", "1616846834");

INSERT INTO package (guid, storeId, bookedTimeId, verificationCode, customerEmail, customerName, externalOrderId, creationDate) VALUES
    (1298, 2, NULL, "akeoifkapekopaei", "mamba@mail.com", "Black Mamba", "#8000BB", "1616846834");